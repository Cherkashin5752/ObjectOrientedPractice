﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ObjectOrientedPractics.Model;
using ObjectOrientedPractics.Model.Enums;

namespace ObjectOrientedPractics.View.Controls
{
    public partial class SelectedOrderControl : UserControl
    {
        /// <summary>
        /// Текущевыбранный заказ.
        /// </summary>
        private Order _currentOrder;

        /// <summary>
        /// Текущий приоритетный заказ.
        /// </summary>
        private PriorityOrder _currentPriorityOrder;

        /// <summary>
        /// Возвращает и задаёт текущевыбранный заказ.
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Order CurrentOrder
        {
            get { return _currentOrder; }
            set
            {
                _currentOrder = value;
                RefreshCurrentOrderInfo();
            }
        }
        
        /// <summary>
        /// Возвращает и щадаёт текущий приоритетный заказ.
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public PriorityOrder CurrentPriorityOrder
        {
            get { return _currentPriorityOrder; }
            set
            {
                _currentPriorityOrder = value;
                RefreshCurrentPriorityOrderInfo();
            }
        }

        /// <summary>
        /// Инициализирует экземпляр класса <see cref="SelectedOrderControl">.
        /// </summary>
        public SelectedOrderControl()
        {
            InitializeComponent();

            addressControl1.ReadOnly = true;

            StatusComboBox.DataSource = Enum.GetValues<OrderStatus>();

            DeliveryTimeComboBox.DataSource = DeliveryTimeRange.DeliveryTimeRangeString;
        }

        /// <summary>
        /// Инициализирует все необходимые элементы состоянием CurrentOrder.
        /// </summary>
        private void RefreshCurrentOrderInfo()
        {
            IdTextBox.Text = CurrentOrder.Id.ToString();
            CreatedTextBox.Text = CurrentOrder.CreateTime.ToString();
            StatusComboBox.SelectedItem = CurrentOrder.Status;
            addressControl1.CurrentAddress = CurrentOrder.Address;
            ItemsOrderListBox.DataSource = CurrentOrder.Items;
            ItemsOrderListBox.DisplayMember = "Name";
            AmountOrderLabel.Text = CurrentOrder.Amount.ToString();
        }

        /// <summary>
        /// Инициализирует все необходимые элементы состоянием CurrentPriorityOrder.
        /// </summary>
        private void RefreshCurrentPriorityOrderInfo()
        {
            if (CurrentPriorityOrder != null)
            {
                DeliveryTimeComboBox.SelectedItem = CurrentPriorityOrder.DeliveryTime;
            }
        }
    }
}
