﻿using ObjectOrientedPractics.Model;
using ObjectOrientedPractics.Model.Enums;
using ObjectOrientedPractics.Service;
using ObjectOrientedPractics.View.Control;
using ObjectOrientedPractics.View.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ObjectOrientedPractics.View.Panels
{
    public partial class PriorityOrdersTab : UserControl
    {
        /// <summary>
        /// Находится ли окно в режиме редактирования или создания.
        /// </summary>
        private bool isEditMode = true;

        /// <summary>
        /// Возвращает и задаёт список приоритетных заказов.
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public BindingList<PriorityOrder> PriorityOrders { get; set; } = new();

        /// <summary>
        /// Возвращает и задаёт список товаров текущего приоритетного заказа.
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public BindingList<Item> CurrentItemsList { get; set; } = new();

        /// <summary>
        /// Возвращает общую стоимость всех товаров в текущем приоритетном казазе.
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public double Amount
        {
            get
            {
                return CurrentItemsList?.Sum(item => item.Cost) ?? 0.0;
            }
        }

        /// <summary>
        /// Инициализирует экземпляр класса <see cref="PriorityOrdersTab">
        /// </summary>
        public PriorityOrdersTab()
        {
            InitializeComponent();

            selectedPriorityOrdersControl1.ItemsPriorityOrderListBox.DataSource = CurrentItemsList;
            selectedPriorityOrdersControl1.ItemsPriorityOrderListBox.DisplayMember = "Name";
            priorityOrderControl1.dataGridView2.DataSource = PriorityOrders;
        }

        /// <summary>
        /// Обработка события изменения выбора заказа DataGridView.
        /// </summary>
        /// <param name="sender">Источник события.</param>
        /// <param name="e">Аргументы события.</param>
        private void DataGridView_SelectionChanged(object sender, EventArgs e)
        {
            if (isEditMode)
            {
                if (priorityOrderControl1.dataGridView2.SelectedRows.Count > 0)
                {
                    PriorityOrder selecterPriorityOrder = (PriorityOrder)priorityOrderControl1.dataGridView2.SelectedRows[0].DataBoundItem;
                    selectedPriorityOrdersControl1.CurrentPriorityOrder = selecterPriorityOrder;
                }
            }
        }

        /// <summary>
        /// Обработка события изменения статуса приоритетного заказа StatusPriorityComboBox.
        /// </summary>
        /// <param name="sender">Источник события.</param>
        /// <param name="e">Аргументы события.</param>
        private void StatusPriorityComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isEditMode)
            {
                if (selectedPriorityOrdersControl1.CurrentPriorityOrder != null)
                {
                    selectedPriorityOrdersControl1.CurrentPriorityOrder.Status = (OrderStatus)selectedPriorityOrdersControl1.StatusComboBox.SelectedItem;
                    priorityOrderControl1.dataGridView2.Refresh();
                }
            }
        }

        /// <summary>
        /// ОБработка события нажатия на кнопку ChangeModeButton.
        /// </summary>
        /// <param name="sender">Источник события.</param>
        /// <param name="e">Аргументы события.</param>
        private void ChangeModeButton_Click(object sender, EventArgs e)
        {
            switch (isEditMode)
            {
                case true:
                    isEditMode = false;
                    selectedPriorityOrdersControl1.AddItemButton.Enabled = true;
                    selectedPriorityOrdersControl1.RemoveItemButton.Enabled = true;
                    selectedPriorityOrdersControl1.CreatePriorityOrderButton.Enabled = true;
                    selectedPriorityOrdersControl1.RemovePriorityOrderButton.Enabled = false;
                    selectedPriorityOrdersControl1.ClearPriorityOrderButton.Enabled = true;
                    selectedPriorityOrdersControl1.addressControl1.ReadOnly = false;
                    selectedPriorityOrdersControl1.DeliveryTimeComboBox.Enabled = true;
                    selectedPriorityOrdersControl1.ChangeModeButton.Text = "Edit Mode";
                    selectedPriorityOrdersControl1.addressControl1.CurrentAddress = new Address();
                    break;
                case false:
                    isEditMode = true;
                    selectedPriorityOrdersControl1.AddItemButton.Enabled = false;
                    selectedPriorityOrdersControl1.RemoveItemButton.Enabled = false;
                    selectedPriorityOrdersControl1.CreatePriorityOrderButton.Enabled = false;
                    selectedPriorityOrdersControl1.RemovePriorityOrderButton.Enabled = true;
                    selectedPriorityOrdersControl1.ClearPriorityOrderButton.Enabled = false;
                    selectedPriorityOrdersControl1.addressControl1.ReadOnly = true;
                    selectedPriorityOrdersControl1.DeliveryTimeComboBox.Enabled = false;
                    selectedPriorityOrdersControl1.ChangeModeButton.Text = "Create Mode";
                    break;
            }
        }

        /// <summary>
        /// Обработка события нажатия на кнопку AddItemButton.
        /// </summary>
        /// <param name="sender">Источник события.</param>
        /// <param name="e">Аргументы события.</param>
        private void AddItemButton_Click(object sender, EventArgs e)
        {
            if (!isEditMode)
            {
                Item newItem = ItemFactory.GenerateItem();
                CurrentItemsList.Add(newItem);
                selectedPriorityOrdersControl1.AmountOrderLabel.Text = Amount.ToString();
            }
        }

        /// <summary>
        /// Обработка события нажатия на кнопку RemoveItemButton.
        /// </summary>
        /// <param name="sender">Источник события.</param>
        /// <param name="e">Аргументы события.</param>
        private void RemoveItemButton_Click(object sender, EventArgs e)
        {
            if (!isEditMode)
            {
                int selectedIndex = selectedPriorityOrdersControl1.ItemsPriorityOrderListBox.SelectedIndex;

                if (selectedIndex != -1)
                {
                    CurrentItemsList.RemoveAt(selectedIndex);
                    selectedPriorityOrdersControl1.AmountOrderLabel.Text = Amount.ToString();
                }
            }
        }

        /// <summary>
        /// Обработка события нажатия на кнопку CreatePriorityOrderButton.
        /// </summary>
        /// <param name="sender">Источник события.</param>
        /// <param name="e">Аргументы события.</param>
        private void CreatePriorityOrderButton_Click(object sender, EventArgs e)
        {
            if (!isEditMode)
            {
                if (selectedPriorityOrdersControl1.addressControl1.AllFieldsAreFilled)
                {
                    if (CurrentItemsList.Count > 0)
                    {
                        if (selectedPriorityOrdersControl1.DeliveryTimeComboBox.SelectedIndex != -1)
                        {
                            PriorityOrder newPriorityOrder = new PriorityOrder(selectedPriorityOrdersControl1.addressControl1.CurrentAddress,
                                                                               CurrentItemsList, CustomerFactory.GenerateCustomer().Fullname,
                                                                               DateTime.Now, (string)selectedPriorityOrdersControl1.DeliveryTimeComboBox.SelectedItem);
                            PriorityOrders.Add(newPriorityOrder);
                            ClearAllFields();
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Обработка события нажатия на кнопку RemovePriorityOrderButton.
        /// </summary>
        /// <param name="sender">Источник события.</param>
        /// <param name="e">Аргументы события.</param>
        private void RemovePriorityOrder_Click(object sender, EventArgs e)
        {
            if (isEditMode)
            {
                if (priorityOrderControl1.dataGridView2.SelectedRows.Count > 0)
                {
                    PriorityOrders.Remove((PriorityOrder)priorityOrderControl1.dataGridView2.SelectedRows[0].DataBoundItem);
                }
            }
        }

        /// <summary>
        /// Обработка события нажатия на кнопку ClearPriorityOrderButton.
        /// </summary>
        /// <param name="sender">Источник события.</param>
        /// <param name="e">Аргументы события.</param>
        private void ClearPriorityOrderButton_Click(object sender, EventArgs e)
        {
            if (!isEditMode)
            {
                ClearAllFields();
            }
        }

        /// <summary>
        /// Очищает все элементы на пользовательском элементе selectedPriorityOrderControl1.
        /// </summary>
        private void ClearAllFields()
        {
            selectedPriorityOrdersControl1.ClearAllFields();
            CurrentItemsList.Clear();
            selectedPriorityOrdersControl1.AmountOrderLabel.Text = Amount.ToString();
        }
    }
}