﻿using ObjectOrientedPractics.Model.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace ObjectOrientedPractics.Model
{
    /// <summary>
    /// Приоритетный заказ
    /// </summary>
    public class PriorityOrder : Order
    {
        /// <summary>
        /// Возвращает и задаёт дату когда доставить заказ
        /// </summary>
        public DateTime DeliveryDate { get; set; }

        /// <summary>
        /// Возвращает и задаёт время когда доставить заказ
        /// </summary>
        public string DeliveryTime { get; set; }

        /// <summary>
        /// Конструктор по умолчанию.
        /// </summary>
        public PriorityOrder() {}

        /// <summary>
        /// Инициализирует экземпляр класса <see cref="PriorityOrder">.
        /// </summary>
        /// <param name="customer">Покупатель, оформляющий заказ</param>
        /// <param name="deliveryDate">Дата когда доставить заказ</param>
        /// <param name="deliveryTime">Время когда доставить заказ</param>
        public PriorityOrder(Customer customer, DateTime deliveryDate,
            string deliveryTime) :
            base(customer)
        {
            DeliveryDate = deliveryDate;
            DeliveryTime = deliveryTime;
        }

        /// <summary>
        /// Инициализирует экземпляр класса <see cref="PriorityOrder">
        /// </summary>
        /// <param name="address">Адрес заказа.</param>
        /// <param name="items">Товары заказа.</param>
        /// <param name="customerFullname">Полное имя покупателя заказа.</param>
        /// <param name="deliveryDate">День доставки заказа.</param>
        /// <param name="deliveryTime">Время доставки заказа.</param>
        public PriorityOrder(Address address, BindingList<Item> items, 
            string customerFullname, DateTime deliveryDate,
            string deliveryTime) :
            base(address, items, customerFullname)
        {
            DeliveryDate = deliveryDate;
            DeliveryTime = deliveryTime;
        }
    }
}