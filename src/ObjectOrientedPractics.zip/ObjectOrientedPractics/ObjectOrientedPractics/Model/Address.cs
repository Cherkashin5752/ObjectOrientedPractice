﻿using ObjectOrientedPractics.Service;
using System.Diagnostics.Metrics;

namespace ObjectOrientedPractics.Model
{
    /// <summary>
    /// Хранит адрес покупателя
    /// </summary>
    public class Address
    {
        /// <summary>
        /// Индекс покупателя
        /// </summary>
        private int _index;

        /// <summary>
        /// Страна (регион) покупателя
        /// </summary>
        private string _country;

        /// <summary>
        /// Город покупателя
        /// </summary>
        private string _city;

        /// <summary>
        /// Улица покупателя
        /// </summary>
        private string _street;

        /// <summary>
        /// номер дома покупателя
        /// </summary>
        private string _building;

        /// <summary>
        /// Номер квартиры/помещения покупателя
        /// </summary>
        private string _apartment;

        /// <summary>
        /// Возвращает и задаёт индекс покупателя 
        /// </summary>
        public int Index
        {
            get { return _index; }
            set
            {
                if (ValueValidator.ValueInRange(value, 100_000, 999_999, "Index"))
                {
                    _index = value;
                }
            }
        }

        /// <summary>
        /// Возвращает и задаёт страну/регион покупателя
        /// </summary>
        public string Country
        {
            get { return _country; }
            set
            {
                if (ValueValidator.AssertStringOnLength(value, 50, "Country"))
                {
                    _country = value;
                }
            }
        }

        /// <summary>
        /// Возвращает и задаёт город покупателя
        /// </summary>
        public string City
        {
            get { return _city; }
            set
            {
                if (ValueValidator.AssertStringOnLength(value, 50, "City"))
                {
                    _city = value;
                }
            }
        }
        /// <summary>
        /// Возвращает и задаёт улицу покупателя
        /// </summary>
        public string Street
        {
            get { return _street; }
            set
            {
                if (ValueValidator.AssertStringOnLength(value, 100, "Street"))
                {
                    _street = value;
                }
            }
        }

        /// <summary>
        /// Возвращает и задаёт номер дома покупателя
        /// </summary>
        public string Building
        {
            get { return _building; }
            set
            {
                if (ValueValidator.AssertStringOnLength(value, 10, "Building"))
                {
                    _building = value;
                }
            }
        }

        /// <summary>
        /// Возвращает и задаёт номер квартиры/помещения покупателя
        /// </summary>
        public string Apartment
        {
            get { return _apartment; }
            set
            {
                if (ValueValidator.AssertStringOnLength(value, 10, "Apartment"))
                {
                    _apartment = value;
                }
            }
        }

        /// <summary>
        /// Конструктор по умолчанию. Инициализирует новый экземпляр класса <see cref="Address"> с дефолтными значениями
        /// </summary>
        public Address()
        {
            Index = 100_000;
            Country = "Default";
            City = "Default";
            Street = "Default";
            Building = "Default";
            Apartment = "Default";
        }

        /// <summary>
        /// Конструктор копирования. Инициализирует новый экземпляр класса <see cref="Address">
        /// </summary>
        /// <param name="address"></param>
        public Address(Address address)
        {
            Index = address.Index;
            Country = address.Country;
            City = address.City;
            Street = address.Street;
            Building = address.Building;
            Apartment = address.Apartment;
        }

        /// <summary>
        /// Возвращает строку, содержащюю все элементы экземпляра
        /// </summary>
        /// <returns>Строка состояния всех полей</returns>
        public override string ToString()
        {
            return $"{Index}, {Country}, {City}, {Street}, {Building}, {Apartment}";
        }
    }
}
